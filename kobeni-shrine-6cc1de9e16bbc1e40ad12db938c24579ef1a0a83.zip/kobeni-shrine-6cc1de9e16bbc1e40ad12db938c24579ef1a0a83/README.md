# kobeni-shrine
shrine 4 kobeni higashiyama from csm HUGE WIP IM NEW AT THIS AAA
link to site : https://cubecrow.github.io/kobeni-shrine/


this is a personal project, im just trying 2 figure out how code n stuff works lmao
i am aware that its messy and bad its just me being silly :)
